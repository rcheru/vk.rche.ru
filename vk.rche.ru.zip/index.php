<?
/*
dev: www.rche.ru
profile: houseprog@ya.ru, icq uin 1308715
*/

header("Location: apanel/index.php");