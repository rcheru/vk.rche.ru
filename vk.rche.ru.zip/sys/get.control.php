<?php
if (isset($_GET['component']))$component=parseString($_GET['component'],4,1);
if (isset($_GET['section']))$section=parseString($_GET['section'],4,1);
