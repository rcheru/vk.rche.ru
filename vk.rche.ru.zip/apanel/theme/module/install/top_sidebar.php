<div class="menu">
<ul>
<li><a class="current" href="install.php">Установка</a></li>
<li><a href="/">На сайт</a></li>
</ul>
</div> 