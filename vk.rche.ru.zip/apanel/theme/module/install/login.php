<?defined('_JEXEC') or die('Restricted access');?>
<div class="header">
    <div class="logo"><a href="#"><img src="<?=$theme_admin?>images/logo.png" alt="" title="" border="0" /></a></div>
    <div class="right_header">Вас приветствует мастер установки!</div>
</div>
