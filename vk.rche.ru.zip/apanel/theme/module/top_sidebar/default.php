<div class="menu">
<ul>
<li><a class="current" href="index.php">Главная</a></li>
<li><a href="http://rche.ru">На блог</a></li>
</ul>
</div> 