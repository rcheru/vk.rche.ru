<?defined('_JEXEC') or die('Restricted access');


header("Location: index.php?component=settings");
